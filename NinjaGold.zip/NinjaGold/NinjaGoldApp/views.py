from django.shortcuts import render, redirect
import random
from time import gmtime, strftime
from datetime import datetime

def index(request):
    if 'gold' not in request.session:
        request.session['gold'] = 0

    if 'activities' not in request.session:
        request.session['activities'] = []
    return render(request, "index.html")

def reset(request):
    request.session.clear()
    return redirect("/")

def process(request):
    print(request.POST['location'])
    timeearned = datetime.now()
    timeearned.strftime("%Y-%m-%d %H:%M %p")
    print(timeearned)
    if request.POST['location'] == 'Farm':
        earned = random.randint(10, 20)
        request.session['gold'] += earned
        activityStr =f"Earned {earned} golds from the Farm! ({timeearned})"
        request.session['activities'].append(activityStr)
        print(earned)
        print('*' *40)
    elif request.POST['location'] == 'Cave':
        earned = random.randint(5, 10)
        request.session['gold'] += earned
        activityStr =f"Earned {earned} golds from the Cave! ({timeearned})"
        request.session['activities'].append(activityStr)
        print(earned)
        print('*' *40)
    elif request.POST['location'] == 'House':
        earned = random.randint(2, 5)
        request.session['gold'] += earned
        activityStr =f"Earned {earned} golds from the House! ({timeearned})"
        request.session['activities'].append(activityStr)
        print(earned)
        print('*' *40)
    elif request.POST['location'] == 'Casino':
        earned = random.randint(-50, 50)
        request.session['gold'] += earned
        if earned >= 0:
            activityStr =f"Earned {earned} golds from the Casino! ({timeearned})"
        else:
            activityStr =f"Entered a casino and lost {earned} golds ... Ouch ..({timeearned})"
        request.session['activities'].append(activityStr)
        print(earned)
        print('*' *40)
    return redirect('/')

